import { addExecutorFilters } from './executor-filters';

void (function main() {
    addExecutorFilters();
})();
