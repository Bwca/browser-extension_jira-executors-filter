export interface Executor {
    executor: string;
    avatar: string;
}
